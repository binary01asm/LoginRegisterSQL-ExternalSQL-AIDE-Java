package com.my.apps;

import android.app.*;
import android.app.Activity;
import android.os.*;
import android.*;
import android.content.*;
import android.content.pm.*;
import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.os.Bundle;
import android.view.View;
import android.view.animation.*;
import android.widget.*;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.*;
import android.content.*;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.io.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import android.graphics.Typeface;
import android.graphics.*;
import android.graphics.BitmapShader;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.animation.LinearInterpolator;
import android.widget.*;
import android.animation.*;
import android.animation.ValueAnimator;



public class RegisterActivity extends Activity {
   
    private DatabaseHelper databaseHelper;
    private static final int REQUEST_CODE_STORAGE_PERMISSION = 1;
    private static final String DATABASE_PATH = Environment.getExternalStorageDirectory() + "/MySQL/";
    private static String fontName;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        onCreateLogic(savedInstanceState);
        setTitle((new Object() {
                     int t;
                     public String toString() {
                         byte[] buf = new byte[11];
                         t = 740969701;
                         buf[0] = (byte) (t >>> 13);
                         t = 1015849588;
                         buf[1] = (byte) (t >>> 13);
                         t = 868774641;
                         buf[2] = (byte) (t >>> 23);
                         t = -632504103;
                         buf[3] = (byte) (t >>> 22);
                         t = -588185734;
                         buf[4] = (byte) (t >>> 22);
                         t = -860195349;
                         buf[5] = (byte) (t >>> 15);
                         t = -368007592;
                         buf[6] = (byte) (t >>> 4);
                         t = -221538668;
                         buf[7] = (byte) (t >>> 11);
                         t = 50473450;
                         buf[8] = (byte) (t >>> 7);
                         t = 823190812;
                         buf[9] = (byte) (t >>> 4);
                         t = 479740049;
                         buf[10] = (byte) (t >>> 17);
                         return new String(buf);
                     }
                 }.toString()));
        // Check and request permissions
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE_STORAGE_PERMISSION);
        } else {
            // Permissions already granted, proceed with database creation
            createDatabaseOnSDCard();
            onCreateLogic(savedInstanceState);
            File directory = new File(DATABASE_PATH);
            if (!directory.exists()) {
                directory.mkdirs(); // Create the directory if it doesn't exist
            }
          }
    }

  
    private void onCreateLogic(Bundle savedInstanceState) {
      
        final LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(8,8,8,8);
        
        final LinearLayout linear = new LinearLayout(this);
        linear.setOrientation(1);
        linear.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
         
        final EditText regUsername = new EditText(this);
        regUsername.setHint("Username");
        animateRainbowText(regUsername);
        regUsername.setTextSize(20f);
        linear.addView(regUsername,params);
        final EditText regPassword = new EditText(this);
        regPassword.setHint("Password");
        animateRainbowText(regPassword);
        regPassword.setTextSize(20f);
        linear.addView(regPassword,params);
        final Button regButton = new Button(this);
        regButton.setHint("Register");
        animateRainbowText(regButton);
        regButton.setTextSize(20f);
        setCornerRadius(regButton,10f);
        linear.addView(regButton,params);
        final TextView loginLink = new TextView(this);
        loginLink.setGravity(1);
        loginLink.setTextSize(15f);
        loginLink.setHint("Already have an account? Login here!");
        animateRainbowText(loginLink);
        linear.addView(loginLink,params);
        setContentView(linear);
        changeActivityFont("SirinStencil");
        
        databaseHelper = new DatabaseHelper(this);

        // Handle Register Button Click
        regButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String username = regUsername.getText().toString().trim();
                    String password = regPassword.getText().toString().trim();

                    if (username.isEmpty() || password.isEmpty()) {
                        Toast.makeText(RegisterActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    } else {
                        boolean isInserted = databaseHelper.insertUser(username, password);
                        if (isInserted) {
                            Toast.makeText(RegisterActivity.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                            // Redirect to Login Activity
                            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish(); // Close the registration activity
                        } else {
                            Toast.makeText(RegisterActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });

        // Handle Login Link Click
        loginLink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Close the registration activity
                }
            });
        
          }
    //////* $$onCreate Method Ended$$ *//////
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_STORAGE_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with database creation
                createDatabaseOnSDCard();
            } else {
                // Permission denied, show a message to the user
                Toast.makeText(this, "Storage permission is required to create the database.", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    private void createDatabaseOnSDCard() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.getWritableDatabase(); // This will create the database file on the SD card
    }
    
    public void changeActivityFont(final String fontnames) {
        fontName = fontnames.concat(".ttf");
        overrideFonts(this,getWindow().getDecorView()); 
    } 
    private void overrideFonts(final android.content.Context context, final View v) {

        try {
            Typeface 
                typeface = Typeface.createFromAsset(getAssets(), fontName);
            if ((v instanceof ViewGroup)) {
                ViewGroup vg = (ViewGroup) v;
                for (int i = 0;
                     i < vg.getChildCount();
                i++) {
                    View child = vg.getChildAt(i);
                    overrideFonts(context, child);
                }
            }
            else {
                if ((v instanceof TextView)) {
                    ((TextView) v).setTypeface(typeface);
                    ((TextView) v).setTextColor(0xff000000);
                }
                else {
                    if ((v instanceof EditText )) {
                        ((EditText) v).setTypeface(typeface);
                        ((EditText) v).setTextColor(0xff000000);
                    }
                    else {
                        if ((v instanceof Button)) {
                            ((Button) v).setTypeface(typeface);
                            ((Button) v).setTextColor(0xff000000);
                        }
                    }
                }
            }
        }
        catch(Exception e)

        {
            Toast.makeText(getApplicationContext(), "Error Loading Font",Toast.LENGTH_SHORT).show();
        }
    }
    
    
    private static View setCornerRadius(View view,float radius){
        // Create a GradientDrawable
        final GradientDrawable gradientDrawable = new GradientDrawable();

        // Set the corner radius (in pixels, convert dp to pixels if needed)
        //float cornerRadius = 10f; // 10dp
        float cornerRadius = radius; // get float Radius
        gradientDrawable.setCornerRadius(cornerRadius);
        int[] Colors = new int[]{0xff3298f2,0xff6742d7};

        // Set the background color
        gradientDrawable.setColors(new int[]{0xff3298f2,0xff6742d7}); // Replace with your color

        gradientDrawable.setGradientType(GradientDrawable.LINEAR_GRADIENT);

        // Set the gradient direction (orientation)
        gradientDrawable.setOrientation(GradientDrawable.Orientation.TL_BR); // Top-Left to Bottom-Right
        // Apply the GradientDrawable as the button's background
        view.setBackground(gradientDrawable);
        view.setElevation(radius);
        return view;
    }
    private static void animateRainbowText(final TextView textView) {
        textView.setShadowLayer(3,4,0,Color.GRAY);
        textView.setTypeface(Typeface.SERIF);
        // Define the colors for the gradient
        final int[] colors = {

            0xFFFF0000, // Red
            0xFFFF7F00, // Orange
            0xFFFFFF00, // Yellow
            0xFF00FF00, // Green
            0xFF00FFFF, // Cyan
            0xFF0000FF, // Blue
            0xFF4B0082, // Indigo
            0xFF9400D3, // Violet
            0xFFC12BFF, // Light Pink
            0xFFFF246A,  // Light Red
            Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE,Color.CYAN,Color.GREEN,Color.YELLOW,Color.RED
        };

        final int[] colors¥ = {
            //Best For Rainbow Colors
            Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE,Color.CYAN,Color.GREEN,Color.YELLOW,Color.RED
        };

        //final float[] positions = {0.0f, 0.13f, 0.26f, 0.39f, 0.52f, 0.65f,0.78f,0.91f,1.0f}; /* set ColorGradient Positions */


        // Create a ValueAnimator to animate the gradient
        ValueAnimator animator = ValueAnimator.ofFloat(0, 1);
        animator.setDuration(5000); // Duration of the animation in milliseconds
        animator.setRepeatCount(ValueAnimator.INFINITE); // Repeat indefinitely
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    float value = (float) animation.getAnimatedValue();

                    // Calculate the start and end positions for the gradient
                    int startX = (int) (value * textView.getWidth());
                    int endX = startX + textView.getWidth();


                    // Create a LinearGradient shader
                    LinearGradient gradient = new LinearGradient(
                        startX, 0, endX, 0,
                        colors¥,
                        (null),
                        //positions, /* If float position Enabled then (null) Remove||Comment */
                        Shader.TileMode.REPEAT
                    );

                    // Apply the shader to the TextView's paint
                    textView.getPaint().setShader(gradient);

                    // Invalidate the TextView to redraw it
                    textView.invalidate();
                }
            });

        // Start the animation
        animator.start();

    }
    
    
}
